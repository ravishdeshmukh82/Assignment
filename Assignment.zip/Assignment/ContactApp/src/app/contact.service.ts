import { Injectable } from "@angular/core";
import { HttpClient,HttpErrorResponse,HttpHeaders } from "@angular/common/http";
import { Observable,throwError,of } from "rxjs";
import { catchError,tap,map } from "rxjs/operators";
import { IContact } from "./contact";
@Injectable({
    providedIn:"root"
})
export class ContactService{
    private serviceUrl='api/contacts';
    constructor(private http:HttpClient){}

    getContacts():Observable<IContact[]>{
        return this.http.get<IContact[]>(this.serviceUrl).pipe(
            tap(),
            catchError(this.handleError)
        );
    }

    getContact(id:number):Observable<IContact>{
        if (id == 0) {
            return of(this.initiallizeContact());
          }
        const url=`${this.serviceUrl}/${id}`;
        return this.http.get<IContact>(url).pipe(
            tap(),
            catchError(this.handleError)
        );
    }

    createContact(contact:IContact):Observable<IContact>{
        contact.id=null;
        const headers = new HttpHeaders({'content-type':'application/json'});
        return this.http.post<IContact>(this.serviceUrl,contact,{headers:headers}).pipe(
            tap(),
            catchError(this.handleError)
        );
    }

    updateContact(contact:IContact):Observable<IContact>{
        const headers = new HttpHeaders({ 'Content-Type': 'application/json'});
        const url = `${this.serviceUrl}/${contact.id}`;
        return this.http.put<IContact>(url,contact,{headers : headers}).pipe(
          tap(()=> console.log('Update contact' + contact.id)),
          map(()=>contact),
          catchError(this.handleError)
        );
      }
      deleteContact(id: number): Observable<{}> {
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        const url = `${this.serviceUrl}/${id}`;
        return this.http.delete<IContact>(url, { headers: headers }).pipe(
          tap(data => console.log('Delete Contact' + id)),
          catchError(this.handleError));
    
      }
    private initiallizeContact(): IContact {
        return {
          id: 0,
          firstName: null,
          lastName: null,
          email: null,
          phoneNo: null,
          status: null
        };
      }

    private handleError(err: HttpErrorResponse) {
        // in a real world app, we may send the server to some remote logging infrastructure
        // instead of just logging it to the console
        let errorMessage = '';
        if (err.error instanceof ErrorEvent) {
          // A client-side or network error occurred. Handle it accordingly.
          errorMessage = `An error occurred: ${err.error.message}`;
        } else {
          // The backend returned an unsuccessful response code.
          // The response body may contain clues as to what went wrong,
          errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);
      }
    
}