import { Component, OnInit} from '@angular/core';
import { FormBuilder,FormGroup,Validators } from "@angular/forms";
import { ActivatedRoute,Router } from "@angular/router";
import { Observable,Subscription,fromEvent,merge } from "rxjs";
import { IContact } from "../contact";
import { ContactService } from "../contact.service";
@Component({
  selector: 'contact-edit',
  templateUrl: './contact-edit.component.html',
  styleUrls: ['./contact-edit.component.css']
})
export class ContactEditComponent implements OnInit {
  pageTitle="Add Contact";
  contactForm:FormGroup;
  contact:IContact;
  errorMessage="";
  private sub:Subscription;
  constructor(private fb:FormBuilder,private contactService:ContactService,private route:ActivatedRoute,
                private router:Router) { }

  ngOnInit() {
    this.contactForm = this.fb.group({
      firstName:['',Validators.required],
      lastName:['',Validators.required],
      email:['',Validators.email],
      phoneNo:'',
      status:['Active',Validators.required]
      
    });
    
    this.sub = this.route.paramMap.subscribe(
      params => {
        const id = +params.get('id');
        
        this.getContact(id);
      }
    );
  }
  ngOnDestroy():void{
    this.sub.unsubscribe();
  }
  getContact(id:number){
    this.contactService.getContact(id).subscribe(
      (data:IContact)=> this.displayContact(data),
      (error:any) => this.errorMessage= <any>error
    );
  }

  displayContact(contact:IContact){
    console.log(contact.id + ' ' + contact.firstName)
    if(this.contactForm){
      this.contactForm.reset();
    }
    this.contact = contact;
    if(this.contact.id === 0){
      this.pageTitle='Add Contact';
    }
    else{
      this.pageTitle = `Edit Contact: ${this.contact.firstName}`;
    }
    this.contactForm.patchValue({
      firstName:this.contact.firstName,
      lastName:this.contact.lastName,
      email:this.contact.email,
      phoneNo:this.contact.phoneNo,
      status:this.contact.status,

    });
    
  }

  saveContact(){
    if(this.contactForm.valid){
      const con = {...this.contact,...this.contactForm.value};
      if(con.status==='select'){
        con.status='';
      }
      if(con.id===0){
        this.contactService.createContact(con).subscribe(
          () => {},
          (error:any)=>this.errorMessage = <any>error
        );
      }
      else{
        this.contactService.updateContact(con).subscribe(
          () => {},
          (error:any)=>this.errorMessage = <any>error
        );
      }
      this.contactForm.reset();
      this.router.navigate(['/contacts']);
    }
    else{
      this.errorMessage = 'Please correct the validation errors.';
    }
    
  }

  deleteContact(){
    if(this.contact.id === 0){
      this.contactForm.reset();
      this.router.navigate(['/contacts']);
    }
    else{
      if(confirm(`Really delete the Contact: ${this.contact.firstName}?`)){
        this.contactService.deleteContact(this.contact.id).subscribe(
          () => { 
            this.contactForm.reset();
            this.router.navigate(['/contacts']);
          },
          (error:any) => this.errorMessage = <any>error
        );
      }
    }
  }
  
}
