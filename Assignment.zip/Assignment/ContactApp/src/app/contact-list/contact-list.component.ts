import { Component, OnInit } from '@angular/core';
import { IContact } from "../contact";
import { ContactService } from "../contact.service";
@Component({
  selector: 'contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit {
  errorMessage='';
  contacts:IContact[];

  constructor(private contactService:ContactService) { }

  ngOnInit() {
    this.contactService.getContacts().subscribe(
      data => this.contacts=data,
      error=> this.errorMessage= <any>error
    );
  }

}
