export interface IContact{
    id:number,
    firstName:string,
    lastName:string,
    email:string,
    phoneNo:string,
    status:string
}