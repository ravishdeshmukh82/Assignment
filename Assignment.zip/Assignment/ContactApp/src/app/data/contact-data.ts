import { InMemoryDbService } from 'angular-in-memory-web-api';
import { IContact } from "../contact";

export class ContactData implements InMemoryDbService{
    createDb() {
        const contacts:IContact[]=[
            {
                "id":1,
                "firstName":"Jon",
                "lastName":"cena",
                "email":"jon@gmail.com",
                "phoneNo":"+1243434",
                "status":"Active"
            },
            {
                "id":2,
                "firstName":"Mery",
                "lastName":"Dsouza",
                "email":"Mery@gmail.com",
                "phoneNo":"+120099",
                "status":"Active"
            },
            {
                "id":3,
                "firstName":"Sam",
                "lastName":"samuals",
                "email":"sam@gmail.com",
                "phoneNo":"+1876698",
                "status":"Inactive"
            },
            {
                "id":4,
                "firstName":"Frank",
                "lastName":"carry",
                "email":"Frank@gmail.com",
                "phoneNo":"+1898778",
                "status":"Inactive"
            }
        ];
        return { contacts };
        
    }

}