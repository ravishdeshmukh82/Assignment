-This application is develouped in a Angular
- to reduce the size I have deleted the node_modules folder
- you need to install NPM
- install the bootstrap
- I have used the inmemory Web APi
 to intall the in memory web API perform below CLI command
npm install angular-in-memory-web-api --save-dev
you can open the code in Visual studio code
- to run the application perform below command
ng s -o
